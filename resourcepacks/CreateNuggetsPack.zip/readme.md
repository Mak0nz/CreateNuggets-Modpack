# Resource Pack for CreateNuggets Modpack
Includes Custom Splash texts

# Included Textures
- [Tom's Create Storage](https://modrinth.com/resourcepack/toms-create-storage)
- [Netherstar to Primogem](https://www.planetminecraft.com/texture-pack/netherstar-to-primogem/)
- [Allure Emoji Pack](https://modrinth.com/resourcepack/allure-emoji-pack)
